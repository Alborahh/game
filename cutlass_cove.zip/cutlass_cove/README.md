# Cutlass Cove

A small original top-down pirate adventure written in Rust with macroquad.
Explore a procedurally generated island, fight skeleton crews with your cutlass,
open chests, and recover the Sunstones. All art is drawn with code - no assets needed.

## Run
Install Rust from https://rustup.rs, then:

    cargo run --release

Linux needs the usual macroquad libraries (e.g. on Debian/Ubuntu:
`sudo apt install libx11-dev libxi-dev libgl1-mesa-dev libasound2-dev`).

## Controls
- WASD / arrows: move
- Mouse aims, left click or Space: swing cutlass (arc in front of you)
- Shift: roll (brief invulnerability)
- E: open a chest when standing next to it
- R: new island after winning

## Ideas to extend
Enemy types, a stamina bar, shops at camp, caves, save files, sound, sprite art.

## Building a Windows .exe
- Easiest: install Rust (https://rustup.rs), then double-click `build_windows.bat`.
  It creates `CutlassCove.exe` in this folder.
- No install: upload this folder to a GitHub repo; the "Build Windows exe" workflow
  (Actions tab) produces a downloadable `cutlass_cove_windows` artifact.
