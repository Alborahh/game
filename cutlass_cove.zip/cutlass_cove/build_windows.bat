@echo off
where cargo >nul 2>nul
if errorlevel 1 (
  echo Rust is not installed. Opening the installer page...
  start https://rustup.rs
  echo Install Rust, then run this file again.
  pause
  exit /b 1
)
cargo build --release
if errorlevel 1 ( echo Build failed. & pause & exit /b 1 )
copy /Y target\release\cutlass_cove.exe .\CutlassCove.exe
echo Done! Run CutlassCove.exe
pause
