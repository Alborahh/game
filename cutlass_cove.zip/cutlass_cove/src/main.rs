//! Cutlass Cove - a small original top-down pirate adventure.
//! Explore the island, fight skeleton crews with your cutlass, open chests,
//! and recover the three Sunstones. All art is drawn with shapes.

use macroquad::prelude::*;
use std::f32::consts::{PI, TAU};

const W: usize = 90;
const H: usize = 70;
const TS: f32 = 32.0;
const MAX_HP: i32 = 5;
const SWING_TIME: f32 = 0.28;
const ROLL_TIME: f32 = 0.30;

// ---------------------------------------------------------------- world ----

#[derive(Clone, Copy, PartialEq)]
enum Tile {
    Water,
    Sand,
    Grass,
    Palm,
    Rock,
}

fn solid(t: Tile) -> bool {
    matches!(t, Tile::Water | Tile::Palm | Tile::Rock)
}

fn hash(x: i32, y: i32, seed: u32) -> f32 {
    let mut h = (x as u32).wrapping_mul(374_761_393)
        ^ (y as u32).wrapping_mul(668_265_263)
        ^ seed.wrapping_mul(2_246_822_519);
    h = (h ^ (h >> 13)).wrapping_mul(1_274_126_177);
    h ^= h >> 16;
    (h & 0xFFFF) as f32 / 65535.0
}

fn smooth(t: f32) -> f32 {
    t * t * (3.0 - 2.0 * t)
}

fn noise(x: f32, y: f32, seed: u32) -> f32 {
    let x0 = x.floor();
    let y0 = y.floor();
    let fx = smooth(x - x0);
    let fy = smooth(y - y0);
    let (xi, yi) = (x0 as i32, y0 as i32);
    let a = hash(xi, yi, seed);
    let b = hash(xi + 1, yi, seed);
    let c = hash(xi, yi + 1, seed);
    let d = hash(xi + 1, yi + 1, seed);
    let top = a + (b - a) * fx;
    let bot = c + (d - c) * fx;
    top + (bot - top) * fy
}

fn fbm(x: f32, y: f32, seed: u32) -> f32 {
    noise(x / 10.0, y / 10.0, seed) * 0.55
        + noise(x / 5.0, y / 5.0, seed + 1) * 0.30
        + noise(x / 2.5, y / 2.5, seed + 2) * 0.15
}

struct World {
    tiles: Vec<Tile>,
    camp: Vec2,
}

impl World {
    fn generate(seed: u32) -> World {
        let mut tiles = vec![Tile::Water; W * H];
        let (cx, cy) = (W as i32 / 2, H as i32 / 2);
        for y in 0..H {
            for x in 0..W {
                let dx = (x as f32 - W as f32 / 2.0) / (W as f32 / 2.0);
                let dy = (y as f32 - H as f32 / 2.0) / (H as f32 / 2.0);
                let d = (dx * dx + dy * dy).sqrt();
                let h = fbm(x as f32, y as f32, seed) * 0.55 + (1.0 - d) * 0.75;
                let mut t = if h < 0.55 {
                    Tile::Water
                } else if h < 0.64 {
                    Tile::Sand
                } else {
                    Tile::Grass
                };
                let r = hash(x as i32, y as i32, seed + 9);
                if t == Tile::Grass && r > 0.88 {
                    t = Tile::Palm;
                } else if t == Tile::Grass && r < 0.03 {
                    t = Tile::Rock;
                } else if t == Tile::Sand && r > 0.97 {
                    t = Tile::Rock;
                }
                if (x as i32 - cx).abs() <= 3 && (y as i32 - cy).abs() <= 3 {
                    t = Tile::Grass;
                }
                tiles[y * W + x] = t;
            }
        }
        World {
            tiles,
            camp: vec2((cx as f32 + 0.5) * TS, (cy as f32 + 0.5) * TS),
        }
    }

    fn tile_at(&self, x: i32, y: i32) -> Tile {
        if x < 0 || y < 0 || x >= W as i32 || y >= H as i32 {
            Tile::Water
        } else {
            self.tiles[y as usize * W + x as usize]
        }
    }

    fn blocked(&self, p: Vec2, r: f32) -> bool {
        for (ox, oy) in [(-r, -r), (r, -r), (-r, r), (r, r)] {
            let tx = ((p.x + ox) / TS).floor() as i32;
            let ty = ((p.y + oy) / TS).floor() as i32;
            if solid(self.tile_at(tx, ty)) {
                return true;
            }
        }
        false
    }

    fn try_move(&self, pos: &mut Vec2, d: Vec2, r: f32) {
        let nx = vec2(pos.x + d.x, pos.y);
        if !self.blocked(nx, r) {
            pos.x = nx.x;
        }
        let ny = vec2(pos.x, pos.y + d.y);
        if !self.blocked(ny, r) {
            pos.y = ny.y;
        }
    }

    /// Random open land position at least `min_dist` pixels from the camp.
    fn random_spot(&self, min_dist: f32) -> Option<Vec2> {
        for _ in 0..500 {
            let x = rand::gen_range(0usize, W);
            let y = rand::gen_range(0usize, H);
            let t = self.tiles[y * W + x];
            if t == Tile::Grass || t == Tile::Sand {
                let p = vec2((x as f32 + 0.5) * TS, (y as f32 + 0.5) * TS);
                if p.distance(self.camp) >= min_dist && !self.blocked(p, 14.0) {
                    return Some(p);
                }
            }
        }
        None
    }
}

// ------------------------------------------------------------- entities ----

struct Player {
    pos: Vec2,
    hp: i32,
    facing: f32,
    swing_t: f32, // > 0 while swinging (counts up from 0.0001)
    swing_hit: bool,
    roll_t: f32,
    roll_cd: f32,
    roll_dir: Vec2,
    invuln: f32,
    kb: Vec2,
}

struct Enemy {
    pos: Vec2,
    home: Vec2,
    hp: i32,
    flash: f32,
    cd: f32,
    kb: Vec2,
    phase: f32,
}

struct Chest {
    pos: Vec2,
    open: bool,
}

struct Game {
    world: World,
    player: Player,
    enemies: Vec<Enemy>,
    chests: Vec<Chest>,
    relics: Vec<Vec2>,
    coins_on_ground: Vec<Vec2>,
    coins: u32,
    relics_found: u32,
    relic_total: u32,
    cam: Vec2,
    msg: String,
    msg_t: f32,
    won: bool,
    minimap: Texture2D,
}

fn angle_diff(a: f32, b: f32) -> f32 {
    let mut d = (a - b) % TAU;
    if d > PI {
        d -= TAU;
    }
    if d < -PI {
        d += TAU;
    }
    d.abs()
}

impl Game {
    fn new() -> Game {
        let seed = (get_time() * 1000.0) as u32 ^ 0x9E37_79B9;
        rand::srand(seed as u64);
        let world = World::generate(seed % 10_000);

        let mut enemies = Vec::new();
        for _ in 0..18 {
            if let Some(p) = world.random_spot(11.0 * TS) {
                enemies.push(Enemy {
                    pos: p,
                    home: p,
                    hp: 3,
                    flash: 0.0,
                    cd: 0.0,
                    kb: Vec2::ZERO,
                    phase: rand::gen_range(0.0f32, TAU),
                });
            }
        }
        let mut chests = Vec::new();
        for _ in 0..9 {
            if let Some(p) = world.random_spot(6.0 * TS) {
                chests.push(Chest { pos: p, open: false });
            }
        }
        let mut relics = Vec::new();
        for _ in 0..3 {
            if let Some(p) = world.random_spot(16.0 * TS) {
                relics.push(p);
            }
        }

        // Minimap image
        let mut img = Image::gen_image_color(W as u16, H as u16, Color::new(0.05, 0.2, 0.4, 1.0));
        for y in 0..H {
            for x in 0..W {
                let c = match world.tiles[y * W + x] {
                    Tile::Water => Color::new(0.05, 0.2, 0.4, 1.0),
                    Tile::Sand => Color::new(0.85, 0.77, 0.5, 1.0),
                    Tile::Grass => Color::new(0.25, 0.55, 0.25, 1.0),
                    Tile::Palm => Color::new(0.15, 0.4, 0.18, 1.0),
                    Tile::Rock => Color::new(0.5, 0.5, 0.5, 1.0),
                };
                img.set_pixel(x as u32, y as u32, c);
            }
        }
        let minimap = Texture2D::from_image(&img);
        minimap.set_filter(FilterMode::Nearest);

        let relic_total = relics.len() as u32;
        let camp = world.camp;
        Game {
            world,
            player: Player {
                pos: camp,
                hp: MAX_HP,
                facing: 0.0,
                swing_t: 0.0,
                swing_hit: false,
                roll_t: 0.0,
                roll_cd: 0.0,
                roll_dir: Vec2::ZERO,
                invuln: 0.0,
                kb: Vec2::ZERO,
            },
            enemies,
            chests,
            relics,
            coins_on_ground: Vec::new(),
            coins: 0,
            relics_found: 0,
            relic_total,
            cam: camp,
            msg: "Find the three Sunstones scattered across the island!".to_string(),
            msg_t: 6.0,
            won: false,
            minimap,
        }
    }

    fn say(&mut self, s: &str) {
        self.msg = s.to_string();
        self.msg_t = 3.0;
    }

    fn update(&mut self, dt: f32) {
        if self.won {
            return;
        }
        let t = get_time() as f32;
        let (sw, sh) = (screen_width(), screen_height());

        // ---- aim & input
        let pscreen = self.player.pos - self.cam + vec2(sw / 2.0, sh / 2.0);
        let (mx, my) = mouse_position();
        let aim = vec2(mx, my) - pscreen;
        if aim.length() > 4.0 && self.player.swing_t <= 0.0 && self.player.roll_t <= 0.0 {
            self.player.facing = aim.y.atan2(aim.x);
        }

        let mut dir = Vec2::ZERO;
        if is_key_down(KeyCode::W) || is_key_down(KeyCode::Up) {
            dir.y -= 1.0;
        }
        if is_key_down(KeyCode::S) || is_key_down(KeyCode::Down) {
            dir.y += 1.0;
        }
        if is_key_down(KeyCode::A) || is_key_down(KeyCode::Left) {
            dir.x -= 1.0;
        }
        if is_key_down(KeyCode::D) || is_key_down(KeyCode::Right) {
            dir.x += 1.0;
        }
        let dir = dir.normalize_or_zero();

        // ---- player timers
        let p = &mut self.player;
        p.invuln = (p.invuln - dt).max(0.0);
        p.roll_cd = (p.roll_cd - dt).max(0.0);

        if (is_mouse_button_pressed(MouseButton::Left) || is_key_pressed(KeyCode::Space))
            && p.swing_t <= 0.0
            && p.roll_t <= 0.0
        {
            p.swing_t = 0.0001;
            p.swing_hit = false;
        }
        if is_key_pressed(KeyCode::LeftShift) && p.roll_t <= 0.0 && p.roll_cd <= 0.0 && p.swing_t <= 0.0 {
            p.roll_t = ROLL_TIME;
            p.roll_cd = 0.7;
            p.roll_dir = if dir != Vec2::ZERO {
                dir
            } else {
                vec2(p.facing.cos(), p.facing.sin())
            };
            p.invuln = p.invuln.max(ROLL_TIME);
        }

        // ---- player movement
        let mut vel = if p.roll_t > 0.0 {
            p.roll_dir * 340.0
        } else if p.swing_t > 0.0 {
            dir * 70.0
        } else {
            dir * 150.0
        };
        vel += p.kb;
        p.kb *= (1.0 - 8.0 * dt).max(0.0);
        if p.roll_t > 0.0 {
            p.roll_t -= dt;
            if p.roll_t < 0.0 {
                p.roll_t = 0.0;
            }
        }
        let mut pos = p.pos;
        self.world.try_move(&mut pos, vel * dt, 10.0);
        p.pos = pos;

        // ---- sword
        let mut hits: Vec<Vec2> = Vec::new();
        if p.swing_t > 0.0 {
            p.swing_t += dt;
            if !p.swing_hit && p.swing_t > 0.07 {
                p.swing_hit = true;
                let facing = p.facing;
                let ppos = p.pos;
                for e in self.enemies.iter_mut() {
                    let to = e.pos - ppos;
                    if to.length() < 56.0 && angle_diff(to.y.atan2(to.x), facing) < 1.1 {
                        e.hp -= 1;
                        e.flash = 0.15;
                        e.kb = to.normalize_or_zero() * 340.0;
                        if e.hp <= 0 {
                            hits.push(e.pos);
                        }
                    }
                }
            }
            if p.swing_t >= SWING_TIME {
                p.swing_t = 0.0;
            }
        }
        for pos in hits {
            let n = rand::gen_range(1, 4);
            for _ in 0..n {
                let off = vec2(rand::gen_range(-12.0f32, 12.0), rand::gen_range(-12.0f32, 12.0));
                self.coins_on_ground.push(pos + off);
            }
        }
        self.enemies.retain(|e| e.hp > 0);

        // ---- enemies
        let ppos = self.player.pos;
        let mut damage_player: Option<Vec2> = None;
        for e in self.enemies.iter_mut() {
            e.cd -= dt;
            e.flash = (e.flash - dt).max(0.0);
            let to = ppos - e.pos;
            let dist = to.length();
            let mut v;
            if dist < 230.0 {
                v = to / dist.max(0.001) * 78.0;
            } else {
                let a = t * 0.5 + e.phase;
                v = vec2(a.cos(), a.sin()) * 20.0;
                if (e.pos - e.home).length() > 90.0 {
                    v = (e.home - e.pos).normalize_or_zero() * 40.0;
                }
            }
            let d = (v + e.kb) * dt;
            e.kb *= (1.0 - 8.0 * dt).max(0.0);
            let mut ep = e.pos;
            self.world.try_move(&mut ep, d, 10.0);
            e.pos = ep;
            if dist < 30.0 && e.cd <= 0.0 && self.player.invuln <= 0.0 {
                damage_player = Some(to.normalize_or_zero());
                e.cd = 1.2;
            }
        }
        if let Some(kb_dir) = damage_player {
            self.player.hp -= 1;
            self.player.invuln = 0.9;
            self.player.kb = kb_dir * 260.0;
            if self.player.hp <= 0 {
                self.player.hp = MAX_HP;
                self.player.pos = self.world.camp;
                self.player.invuln = 2.0;
                self.coins /= 2;
                self.say("You were knocked out! You wake up at camp, a few coins lighter.");
            }
        }

        // ---- pickups
        let ppos = self.player.pos;
        let mut gained = 0u32;
        for c in self.coins_on_ground.iter_mut() {
            let d = ppos - *c;
            if d.length() < 70.0 {
                *c += d.normalize_or_zero() * 260.0 * dt;
            }
        }
        self.coins_on_ground.retain(|c| {
            if c.distance(ppos) < 16.0 {
                gained += 1;
                false
            } else {
                true
            }
        });
        self.coins += gained;

        let mut found = 0u32;
        self.relics.retain(|r| {
            if r.distance(ppos) < 24.0 {
                found += 1;
                false
            } else {
                true
            }
        });
        if found > 0 {
            self.relics_found += found;
            if self.relics_found >= self.relic_total {
                self.won = true;
            } else {
                let m = format!("Sunstone recovered! ({}/{})", self.relics_found, self.relic_total);
                self.say(&m);
            }
        }

        if is_key_pressed(KeyCode::E) {
            let mut opened: Option<usize> = None;
            for (i, c) in self.chests.iter().enumerate() {
                if !c.open && c.pos.distance(ppos) < 34.0 {
                    opened = Some(i);
                    break;
                }
            }
            if let Some(i) = opened {
                self.chests[i].open = true;
                let roll = rand::gen_range(0, 10);
                if roll < 3 && self.player.hp < MAX_HP {
                    self.player.hp += 1;
                    self.say("Fresh rations! +1 heart");
                } else {
                    let amount = rand::gen_range(10u32, 31);
                    self.coins += amount;
                    let m = format!("Found {} gold coins!", amount);
                    self.say(&m);
                }
            }
        }

        // ---- camera & message timer
        let k = 1.0 - (-8.0 * dt).exp();
        self.cam += (self.player.pos - self.cam) * k;
        if self.msg_t > 0.0 {
            self.msg_t -= dt;
        }
    }

    fn draw(&self) {
        let (sw, sh) = (screen_width(), screen_height());
        let t = get_time() as f32;
        clear_background(Color::new(0.09, 0.33, 0.58, 1.0));
        let off = vec2(sw / 2.0, sh / 2.0) - self.cam;

        // ---- tiles
        let x0 = (((self.cam.x - sw / 2.0) / TS).floor() as i32).max(0);
        let y0 = (((self.cam.y - sh / 2.0) / TS).floor() as i32).max(0);
        let x1 = (((self.cam.x + sw / 2.0) / TS).ceil() as i32).min(W as i32);
        let y1 = (((self.cam.y + sh / 2.0) / TS).ceil() as i32).min(H as i32);
        for ty in y0..y1 {
            for tx in x0..x1 {
                let tile = self.world.tile_at(tx, ty);
                let sx = tx as f32 * TS + off.x;
                let sy = ty as f32 * TS + off.y;
                match tile {
                    Tile::Water => {
                        if (tx + ty) % 3 == 0 {
                            let w = (t * 1.5 + tx as f32 * 0.7 + ty as f32).sin() * 4.0;
                            draw_line(sx + 6.0, sy + 16.0 + w, sx + 26.0, sy + 16.0 + w, 2.0,
                                Color::new(0.35, 0.6, 0.85, 0.6));
                        }
                    }
                    Tile::Sand => {
                        draw_rectangle(sx, sy, TS, TS, Color::new(0.86, 0.78, 0.52, 1.0));
                    }
                    Tile::Grass | Tile::Palm | Tile::Rock => {
                        let shade = 0.5 + hash(tx, ty, 77) * 0.08;
                        draw_rectangle(sx, sy, TS, TS, Color::new(0.22, shade, 0.24, 1.0));
                        if tile == Tile::Palm {
                            draw_rectangle(sx + 14.0, sy + 12.0, 5.0, 18.0, Color::new(0.45, 0.3, 0.15, 1.0));
                            let sway = (t + tx as f32).sin() * 2.0;
                            draw_circle(sx + 16.0 + sway, sy + 8.0, 13.0, Color::new(0.12, 0.45, 0.16, 1.0));
                            draw_circle(sx + 10.0 + sway, sy + 12.0, 8.0, Color::new(0.16, 0.52, 0.2, 1.0));
                            draw_circle(sx + 23.0 + sway, sy + 12.0, 8.0, Color::new(0.16, 0.52, 0.2, 1.0));
                        } else if tile == Tile::Rock {
                            draw_circle(sx + 16.0, sy + 18.0, 12.0, Color::new(0.45, 0.45, 0.48, 1.0));
                            draw_circle(sx + 13.0, sy + 15.0, 6.0, Color::new(0.6, 0.6, 0.63, 1.0));
                        }
                    }
                }
            }
        }

        // ---- camp flag
        let cp = self.world.camp + off;
        draw_rectangle(cp.x - 2.0, cp.y - 40.0, 4.0, 40.0, Color::new(0.4, 0.28, 0.14, 1.0));
        draw_triangle(vec2(cp.x + 2.0, cp.y - 40.0), vec2(cp.x + 30.0, cp.y - 32.0),
            vec2(cp.x + 2.0, cp.y - 24.0), Color::new(0.75, 0.1, 0.1, 1.0));

        // ---- chests
        for c in &self.chests {
            let p = c.pos + off;
            let body = if c.open { Color::new(0.35, 0.22, 0.1, 1.0) } else { Color::new(0.55, 0.35, 0.15, 1.0) };
            draw_rectangle(p.x - 13.0, p.y - 8.0, 26.0, 16.0, body);
            draw_rectangle(p.x - 13.0, p.y - 2.0, 26.0, 3.0, Color::new(0.9, 0.75, 0.2, 1.0));
            if !c.open {
                draw_circle(p.x, p.y, 3.0, Color::new(0.95, 0.85, 0.3, 1.0));
                if c.pos.distance(self.player.pos) < 34.0 {
                    draw_text("E", p.x - 5.0, p.y - 16.0, 22.0, WHITE);
                }
            }
        }

        // ---- relics (Sunstones)
        for r in &self.relics {
            let p = *r + off;
            let pulse = 0.5 + 0.5 * (t * 3.0).sin();
            draw_circle(p.x, p.y, 18.0 + pulse * 6.0, Color::new(1.0, 0.85, 0.2, 0.25));
            draw_poly(p.x, p.y - 2.0 * (t * 2.0).sin(), 4, 11.0, 0.0, Color::new(1.0, 0.8, 0.15, 1.0));
            draw_poly(p.x, p.y - 2.0 * (t * 2.0).sin(), 4, 6.0, 0.0, Color::new(1.0, 0.97, 0.7, 1.0));
        }

        // ---- coins
        for c in &self.coins_on_ground {
            let p = *c + off;
            draw_circle(p.x, p.y, 5.0, Color::new(0.95, 0.78, 0.15, 1.0));
            draw_circle(p.x, p.y, 2.5, Color::new(1.0, 0.92, 0.5, 1.0));
        }

        // ---- enemies (skeleton crew)
        for e in &self.enemies {
            let p = e.pos + off;
            draw_circle(p.x, p.y + 12.0, 10.0, Color::new(0.0, 0.0, 0.0, 0.25));
            let body = if e.flash > 0.0 { Color::new(1.0, 0.4, 0.4, 1.0) } else { Color::new(0.85, 0.85, 0.8, 1.0) };
            draw_rectangle(p.x - 6.0, p.y - 2.0, 12.0, 16.0, Color::new(0.25, 0.2, 0.3, 1.0));
            draw_circle(p.x, p.y - 8.0, 9.0, body);
            draw_circle(p.x - 3.5, p.y - 9.0, 2.0, BLACK);
            draw_circle(p.x + 3.5, p.y - 9.0, 2.0, BLACK);
            draw_rectangle(p.x - 3.0, p.y - 3.0, 6.0, 2.0, BLACK);
            // hp pips
            for i in 0..e.hp {
                draw_rectangle(p.x - 9.0 + i as f32 * 7.0, p.y - 24.0, 5.0, 3.0, Color::new(0.9, 0.2, 0.2, 1.0));
            }
        }

        // ---- player
        let p = self.player.pos + off;
        let blink = self.player.invuln > 0.0 && ((t * 20.0) as i32 % 2 == 0) && self.player.roll_t <= 0.0;
        if !blink {
            draw_circle(p.x, p.y + 12.0, 10.0, Color::new(0.0, 0.0, 0.0, 0.25));
            let coat = Color::new(0.15, 0.25, 0.6, 1.0);
            draw_rectangle(p.x - 7.0, p.y - 3.0, 14.0, 17.0, coat);
            draw_circle(p.x, p.y - 8.0, 8.0, Color::new(0.95, 0.78, 0.6, 1.0));
            // hat
            draw_triangle(vec2(p.x - 12.0, p.y - 12.0), vec2(p.x + 12.0, p.y - 12.0),
                vec2(p.x, p.y - 24.0), Color::new(0.1, 0.1, 0.12, 1.0));
            draw_rectangle(p.x - 12.0, p.y - 13.0, 24.0, 3.0, Color::new(0.1, 0.1, 0.12, 1.0));
            // bandana stripe
            draw_rectangle(p.x - 7.0, p.y - 5.0, 14.0, 2.0, Color::new(0.8, 0.15, 0.15, 1.0));
        }
        // cutlass
        let f = self.player.facing;
        if self.player.swing_t > 0.0 {
            let prog = (self.player.swing_t / SWING_TIME).min(1.0);
            let cur = f - 1.1 + 2.2 * prog;
            for i in 0..8 {
                let a0 = f - 1.1 + 2.2 * prog * (i as f32 / 8.0);
                let a1 = f - 1.1 + 2.2 * prog * ((i + 1) as f32 / 8.0);
                draw_triangle(
                    p,
                    p + vec2(a0.cos(), a0.sin()) * 50.0,
                    p + vec2(a1.cos(), a1.sin()) * 50.0,
                    Color::new(1.0, 1.0, 1.0, 0.04 + 0.03 * i as f32),
                );
            }
            let tip = p + vec2(cur.cos(), cur.sin()) * 46.0;
            draw_line(p.x, p.y, tip.x, tip.y, 5.0, Color::new(0.85, 0.88, 0.95, 1.0));
        } else {
            let a = f + 0.6;
            let tip = p + vec2(a.cos(), a.sin()) * 24.0;
            draw_line(p.x, p.y + 2.0, tip.x, tip.y + 2.0, 3.0, Color::new(0.8, 0.83, 0.9, 1.0));
        }

        self.draw_hud(sw, sh);
    }

    fn draw_hud(&self, sw: f32, sh: f32) {
        // hearts
        for i in 0..MAX_HP {
            let c = if i < self.player.hp { Color::new(0.9, 0.15, 0.2, 1.0) } else { Color::new(0.25, 0.1, 0.12, 1.0) };
            draw_circle(26.0 + i as f32 * 30.0, 28.0, 11.0, c);
            draw_circle(26.0 + i as f32 * 30.0 - 3.0, 25.0, 3.0, Color::new(1.0, 1.0, 1.0, 0.35));
        }
        draw_circle(26.0, 64.0, 8.0, Color::new(0.95, 0.78, 0.15, 1.0));
        draw_text(&format!("{}", self.coins), 42.0, 71.0, 28.0, WHITE);
        draw_poly(26.0, 98.0, 4, 9.0, 0.0, Color::new(1.0, 0.8, 0.15, 1.0));
        draw_text(&format!("Sunstones {}/{}", self.relics_found, self.relic_total), 42.0, 105.0, 28.0, WHITE);

        // minimap
        let mw = W as f32 * 2.0;
        let mh = H as f32 * 2.0;
        let mx = sw - mw - 14.0;
        let my = 14.0;
        draw_rectangle(mx - 3.0, my - 3.0, mw + 6.0, mh + 6.0, Color::new(0.0, 0.0, 0.0, 0.6));
        draw_texture_ex(&self.minimap, mx, my, WHITE, DrawTextureParams {
            dest_size: Some(vec2(mw, mh)),
            ..Default::default()
        });
        let pp = self.player.pos / TS * 2.0;
        draw_circle(mx + pp.x, my + pp.y, 3.0, Color::new(1.0, 0.3, 0.3, 1.0));
        for r in &self.relics {
            let rp = *r / TS * 2.0;
            draw_circle(mx + rp.x, my + rp.y, 2.5, Color::new(1.0, 0.9, 0.2, 1.0));
        }

        // message
        if self.msg_t > 0.0 {
            let size = 28.0;
            let dim = measure_text(&self.msg, None, size as u16, 1.0);
            let x = sw / 2.0 - dim.width / 2.0;
            draw_rectangle(x - 12.0, sh - 78.0, dim.width + 24.0, 42.0, Color::new(0.0, 0.0, 0.0, 0.55));
            draw_text(&self.msg, x, sh - 48.0, size, WHITE);
        }
        draw_text("WASD move   Mouse/Space attack   Shift roll   E open chest", 16.0, sh - 12.0, 20.0,
            Color::new(1.0, 1.0, 1.0, 0.7));

        if self.won {
            draw_rectangle(0.0, 0.0, sw, sh, Color::new(0.0, 0.0, 0.0, 0.7));
            let s = "All Sunstones recovered - the cove is yours!";
            let d = measure_text(s, None, 40, 1.0);
            draw_text(s, sw / 2.0 - d.width / 2.0, sh / 2.0 - 10.0, 40.0, Color::new(1.0, 0.85, 0.3, 1.0));
            let s2 = format!("Gold: {}    Press R to sail again", self.coins);
            let d2 = measure_text(&s2, None, 28, 1.0);
            draw_text(&s2, sw / 2.0 - d2.width / 2.0, sh / 2.0 + 36.0, 28.0, WHITE);
        }
    }
}

fn window_conf() -> Conf {
    Conf {
        window_title: "Cutlass Cove".to_owned(),
        window_width: 1100,
        window_height: 700,
        ..Default::default()
    }
}

#[macroquad::main(window_conf)]
async fn main() {
    let mut game = Game::new();
    loop {
        let dt = get_frame_time().min(0.05);
        if game.won && is_key_pressed(KeyCode::R) {
            game = Game::new();
        }
        game.update(dt);
        game.draw();
        next_frame().await;
    }
}
